<?php phpinfo(); ?>

<?php

error_reporting(E_ALL);
ini_set('display_errors', 1); // SET IT TO 0 ON A LIVE SERVER !!!
ini_set('display_startup_errors', 1); // SET IT TO 0 ON A LIVE SERVER !!!

$ver = SQLite3::version();
//echo $ver;
//session_start();
//if(!empty($_SESSION["userId"])) {
//    require_once './view/dashboard.php';
//} else {
//    require_once './view/login-form.php';
//}
?>
