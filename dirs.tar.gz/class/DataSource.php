<?php
//namespace Phppot;

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);


class DataSource
{
    const DATABASENAME = "sql/prova.db"; //'phpsamples';

    private $conn;
    
    function __construct()
    {
        $this->conn = new SQLite3(self::DATABASENAME);
        
        $create_query = "CREATE TABLE IF NOT EXISTS `registered_users` (`id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,`user_name` VARCHAR(255) NOT NULL,`display_name` VARCHAR(255) NOT NULL,`password` VARCHAR(255) NOT NULL,`email` VARCHAR(255) NOT NULL);";

	$this->conn->exec($create_query);
        //return $conn;
    }

    public function select($query, $paramType=array(), $paramArray=array())
    {
        $stmt = $this->conn->prepare($query);
        
	if(!empty($paramType) && !empty($paramArray)) {
		$i = 0;
		foreach ($paramArray as $value) {
			$stmt->bindValue($i+1, $value, $paramType[$i]);
			$i = $i + 1;
		}
        }
        
	$res = $stmt->execute();
	while ($row = $res->fetchArray()) {
		echo "{$row['id']}";
        	$resultset[] = $row;
        }
        
        if (! empty($resultset)) {
            return $resultset;
        }
    }
    
    /**
     * To insert
     * @param string $query
     * @param string $paramType
     * @param array $paramArray
     * @return int
     */
    public function insert($query, $paramType, $paramArray)
    {
        print $query;
        $stmt = $this->conn->prepare($query);
        $this->bindQueryParams($stmt, $paramType, $paramArray);
        $stmt->execute();
        $insertId = $stmt->insert_id;
        return $insertId;
    }
    
    /**
     * To execute query
     * @param string $query
     * @param string $paramType
     * @param array $paramArray
     */
    public function execute($query, $paramType="", $paramArray=array())
    {
        $stmt = $this->conn->prepare($query);
        
        if(!empty($paramType) && !empty($paramArray)) {
            $this->bindQueryParams($stmt, $paramType="", $paramArray=array());
        }
        $stmt->execute();
    }
    
    /**
     * 1. Prepares parameter binding
     * 2. Bind prameters to the sql statement
     * @param string $stmt
     * @param string $paramType
     * @param array $paramArray
     */
    public function bindQueryParams($stmt, $paramType, $paramArray=array())
    {
        $paramValueReference[] = & $paramType;
        for ($i = 0; $i < count($paramArray); $i ++) {
            $paramValueReference[] = & $paramArray[$i];
        }
        call_user_func_array(array(
            $stmt,
            'bind_param'
        ), $paramValueReference);
    }
    
    /**
     * To get database results
     * @param string $query
     * @param string $paramType
     * @param array $paramArray
     * @return array
     */
    public function numRows($query, $paramType="", $paramArray=array())
    {
        $stmt = $this->conn->prepare($query);
        
        if(!empty($paramType) && !empty($paramArray)) {
            $this->bindQueryParams($stmt, $paramType, $paramArray);
        }
        
        $stmt->execute();
        $stmt->store_result();
        $recordCount = $stmt->num_rows;
        return $recordCount;
    }
}
