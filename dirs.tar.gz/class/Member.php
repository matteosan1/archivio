<?php
//namespace Phppot;

//use DataSource;

class Member
{
    //private $dbConn;
    private $ds;

    function __construct()
    {
        require_once "DataSource.php";
        $this->ds = new DataSource();
    }

    function getMemberById($memberId)
    {
        $query = "SELECT * FROM registered_users WHERE id = ?";
        $paramType = array(SQLITE3_INTEGER);
        $paramArray = array($memberId);
        $memberResult = $this->ds->select($query, $paramType, $paramArray);
        
        return $memberResult;
    }
    
    public function processLogin($username, $password) {
        $passwordHash = md5($password);
        $query = "SELECT * FROM registered_users WHERE user_name = ? AND password = ?";
        $paramType = array(SQLITE3_TEXT, SQLITE3_TEXT);
        $paramArray = array($username, $passwordHash);
	$memberResult = $this->ds->select($query, $paramType, $paramArray);
	if(!empty($memberResult)) {
            $_SESSION["userId"] = $memberResult[0]["id"];
            return true;
        }
    }


    public function updateUser($username, $password, $role, $email) {
	$passwordHash = md5($password);
	$query = "INSERT OR REPLACE INTO registered_users () VALUES(?, ?, ?, ?) WHERE 'user_name' = ?;";
	$paramType = array(SQLITE3_TEXT, SQLITE3_TEXT, SQLITE3_TEXT, SQLITE3_TEXT, SQLITE3_TEXT);
	$paramArray = array($username, $passwordHash, $email, $role, $username);
	$res = $this->ds->exec($query, $paramType, $paramArray);
	if ($res) {
	 	echo "SUCCESSO";
	} else {
		echo "NO";
	}
    }

}
