<?php
    $qlite = new SQLITE3("../sql/prova.db");
  
?> 
