<?php
    
	require 'db_config.php';
  
 	$parentKey = '0';
    	$sql = "SELECT * FROM tags";
  
    	$result = $sqlite->query($sql);
  	echo "ECCOMI"; 
	if ($result->numRows() > 0) {
		echo "PROVA";
        	$data = membersTree($parentKey);
      	} else {
        	$data=["id"=>"0","name"=>"No Members present in list","text"=>"No Members is present in list","nodes"=>[]];
      	}
   
      	function membersTree($parentKey) {
		require 'db_config.php';
  
          	$sql = 'SELECT id, name from tags WHERE parent_id="'.$parentKey.'"';
  
          	$result = $sqlite->query($sql);
  
          	while($row = $result->fetchArray() {
 			$id = $value['id'];
             		$row1[$id]['id'] = $value['id'];
             		$row1[$id]['name'] = $value['name'];
             		$row1[$id]['text'] = $value['name'];
             		$row1[$id]['nodes'] = array_values(membersTree($value['id']));
          	}
  
          	return $row1;
      	}
  
      	echo json_encode(array_values($data));
?>
